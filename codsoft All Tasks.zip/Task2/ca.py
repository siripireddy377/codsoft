def calculator():
    print("Welcome to the Calculator")
    
    while True:
        try:
            num1 = float(input("\nEnter the first number: "))
            num2 = float(input("Enter the second number: "))
        except ValueError:
            print("Invalid input! Please enter valid numbers.")
            continue
        
        print("\nChoose the operation:")
        print("1. Addition (+)")
        print("2. Subtraction (-)")
        print("3. Multiplication (*)")
        print("4. Division (/)")
        print("5. Modulus (%)")
        print("6. Exponentiation (^)")
        print("7. Floor Division (//)")
        print("8. Exit")

        operation = input("\nEnter the operation (1/2/3/4/5/6/7/8): ")

        if operation == '1':
            result = num1 + num2
            print(f"\n{num1} + {num2} = {result}")
        
        elif operation == '2':
            result = num1 - num2
            print(f"\n{num1} - {num2} = {result}")
        
        elif operation == '3':
            result = num1 * num2
            print(f"\n{num1} * {num2} = {result}")
        
        elif operation == '4':
            if num2 != 0:
                result = num1 / num2
                print(f"\n{num1} / {num2} = {result}")
            else:
                print("\nError! Division by zero is not allowed.")
        
        elif operation == '5':
            result = num1 % num2
            print(f"\n{num1} % {num2} = {result}")
        
        elif operation == '6':
            result = num1 ** num2
            print(f"\n{num1} ^ {num2} = {result}")
        
        elif operation == '7':
            if num2 != 0:
                result = num1 // num2
                print(f"\n{num1} // {num2} = {result}")
            else:
                print("\nError! Division by zero is not allowed.")
        
        elif operation == '8':
            print("\nExiting the calculator.TATA BYE BYE!")
            break
        
        else:
            print("\nInvalid operation choice. Please try again.")

calculator()

# Explanation:
# 1. The program starts by greeting the user.
# 2. It asks the user for two numbers and makes sure they are valid numbers.
# 3. The user is then asked to choose what kind of calculation to do (add, subtract, etc.).
# 4. The program performs the calculation based on the user's choice and shows the result.
# 5. If the user tries to divide by zero, it shows an error.
# 6. The user can do as many calculations as they want. Choosing option 8 exits the program.
# 7. If the user picks an invalid option, it asks them to try again.
