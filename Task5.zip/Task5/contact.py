import pickle

contacts = {}

def load_contacts():
    global contacts
    try:
        with open('contacts.pkl', 'rb') as file:
            contacts = pickle.load(file)
    except FileNotFoundError:
        contacts = {}

def save_contacts():
    with open('contacts.pkl', 'wb') as file:
        pickle.dump(contacts, file)

def add_contact():
    name = input("Enter contact name: ")
    phone = input("Enter phone number: ")
    email = input("Enter email address: ")
    address = input("Enter address: ")
    contacts[name] = {'phone': phone, 'email': email, 'address': address}
    save_contacts()
    print("Contact added successfully!")

def view_contacts():
    if not contacts:
        print("No contacts available.")
        return
    for name, details in contacts.items():
        print(f"Name: {name}")
        print(f"Phone: {details['phone']}")
        print(f"Email: {details['email']}")
        print(f"Address: {details['address']}")
        print("-" * 20)

def search_contact():
    search_term = input("Enter contact name or phone number to search: ")
    found = False
    for name, details in contacts.items():
        if search_term.lower() in name.lower() or search_term in details['phone']:
            print(f"Name: {name}")
            print(f"Phone: {details['phone']}")
            print(f"Email: {details['email']}")
            print(f"Address: {details['address']}")
            print("-" * 20)
            found = True
    if not found:
        print("No contacts found.")

def update_contact():
    name = input("Enter the name of the contact to update: ")
    if name in contacts:
        phone = input(f"Enter new phone number (current: {contacts[name]['phone']}): ")
        email = input(f"Enter new email address (current: {contacts[name]['email']}): ")
        address = input(f"Enter new address (current: {contacts[name]['address']}): ")
        contacts[name] = {'phone': phone, 'email': email, 'address': address}
        save_contacts()
        print("Contact updated successfully!")
    else:
        print("Contact not found.")

def delete_contact():
    name = input("Enter the name of the contact to delete: ")
    if name in contacts:
        del contacts[name]
        save_contacts()
        print("Contact deleted successfully!")
    else:
        print("Contact not found.")

def main_menu():
    load_contacts()
    while True:
        print("\nContact Management System")
        print("1. Add Contact")
        print("2. View Contacts")
        print("3. Search Contact")
        print("4. Update Contact")
        print("5. Delete Contact")
        print("6. Exit")
        choice = input("Enter your choice: ")

        if choice == '1':
            add_contact()
        elif choice == '2':
            view_contacts()
        elif choice == '3':
            search_contact()
        elif choice == '4':
            update_contact()
        elif choice == '5':
            delete_contact()
        elif choice == '6':
            save_contacts()
            print("Exiting...")
            break
        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main_menu()


#Explanation
# This code is a simple contact management system. It allows users to add, view, search, update and delete contacts. 
# The contacts are stored in a dictionary where the keys are the contact names and the values are dictionaries containing the contact details.
# The contacts are saved to a file called 'contacts.txt' when the program exits or when the user chooses to save the contacts.
# The program uses a simple text-based menu to interact with the user.
# The code is well-structured and follows good practices such as using functions to organize the code and using comments to explain what each part of the code does.